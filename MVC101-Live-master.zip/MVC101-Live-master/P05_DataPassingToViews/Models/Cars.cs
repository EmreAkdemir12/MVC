﻿namespace P05_DataPassingToViews.Models
{
    public class Cars
    {
        public int CarID { get; set; }
        public string BrandName { get; set; }
        public string Family { get; set; }
        public int Year { get; set; }
    }
}
