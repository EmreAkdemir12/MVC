﻿namespace P05_DataPassingToViews.Models
{
    public class Authors
    {
        public int AuthorID { get; set; }
        public string AuthorName { get; set; }
        public string BookName { get; set; }

    }
}
