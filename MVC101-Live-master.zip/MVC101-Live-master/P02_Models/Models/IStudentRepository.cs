﻿namespace P02_Models.Models
{
    public interface IStudentRepository
    {
        Student Get(int StudentID);
    }
}
